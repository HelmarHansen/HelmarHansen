#!/usr/bin/env python3
"""Setzt die SVG-Scheiben in README.md ein, aber nur zwischen den Markierungen.

Alles außerhalb von <!-- console:start --> und <!-- console:end --> bleibt von Hand editierbar.
"""
import os
import re
import sys

from common import CONFIG_PATH, MANIFEST_PATH, ROOT, esc, load_json, write_if_changed
import game as game_mod

START = "<!-- console:start -->"
END = "<!-- console:end -->"


def build_block(manifest):
    lines = ['<p align="center">']
    rows = manifest["rows"]
    extra = None
    if manifest.get("game"):
        extra = game_mod.block(load_json(CONFIG_PATH), manifest["game"], game_mod.load_state())
    for ri, row in enumerate(rows):
        if extra and ri == len(rows) - 1:
            lines.append("</p>")
            lines.append(extra)
            lines.append('<p align="center">')
        n = len(row)
        parts = []
        for item in row:
            width = "100%" if n == 1 else f"{100 / n:g}%"
            img = f'<img src="./{item["file"]}" width="{width}" align="top" alt="{esc(item["alt"])}">'
            if item.get("href"):
                img = f'<a href="{esc(item["href"])}">{img}</a>'
            parts.append(img)
        # Bilder in einer Reihe stehen ohne Leerraum nebeneinander, sonst entstehen Lücken.
        lines.append("".join(parts))
    lines.append("</p>")
    return "\n".join(lines)


def build_page(page):
    here = os.path.dirname(page["path"])
    lines = []
    for row in page["rows"]:
        n = len(row)
        parts = []
        for item in row:
            width = item.get("pct") or (100 if n == 1 else round(100 / n, 4))
            img = f'<img src="{os.path.relpath(item["file"], here).replace(os.sep, "/")}" width="{width:g}%" align="top" alt="{esc(item["alt"])}">'
            if item.get("href"):
                img = f'<a href="{esc(item["href"])}">{img}</a>'
            parts.append(img)
        lines.append('<p align="center">')
        lines.append("".join(parts))
        lines.append("</p>")
        lines.append("")
    return "\n".join(lines)


def main():
    manifest = load_json(MANIFEST_PATH)
    if not manifest:
        sys.exit("fehler: manifest.json fehlt (zuerst render.py ausführen).")
    path = os.path.join(ROOT, "README.md")
    with open(path, encoding="utf-8") as f:
        text = f.read()
    if text.count(START) != 1 or text.count(END) != 1:
        sys.exit(f"fehler: README.md braucht genau je eine Markierung {START} und {END}.")
    block = f"{START}\n{build_block(manifest)}\n{END}"
    new = re.sub(re.escape(START) + r".*?" + re.escape(END), lambda _: block, text, flags=re.S)
    changed = write_if_changed(path, new)
    print("README.md aktualisiert." if changed else "README.md unverändert.")


if __name__ == "__main__":
    main()
